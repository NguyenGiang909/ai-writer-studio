# AI Writer Studio — bản tham chiếu demo v14

## Xem giao diện giống bản demo

Mở `dist/index.html` bằng trình duyệt. Đây là chính HTML/CSS/JavaScript của bản xuất v14, không phải giao diện dựng lại từ mô tả. Có thể chạy `python3 -m http.server 8000 --directory dist` rồi mở `http://localhost:8000/`.

## Bàn giao cho AI agent tiếp tục làm web

**Yêu cầu:** Dùng `dist/index.html` làm chuẩn trực quan và hành vi. Giữ bố cục ba cột, cây Volume → Arc → Chapter → Scene, nội dung mẫu, màu sáng/tối, kiểu chữ, kích thước và trạng thái tương tác. Đối chiếu trên desktop và mobile trước khi thay framework. Nếu port sang React/Vue, chia thành component từ HTML hiện hữu và so lại từng màn hình; không dựng lại chỉ từ JSON hoặc README.

`sample-data/thanh-pho-khong-ngu.sample.json` là dữ liệu minh họa để thiết kế model dữ liệu, **không chứa toàn bộ giao diện, CSS, trạng thái UI hay đầy đủ nội dung demo**. Đừng dùng JSON này làm chuẩn duy nhất để tái tạo trang.

## Tình trạng chức năng

Đây là demo một trang. Nhiều nút chỉ hiển thị thông báo hoặc trạng thái giả lập. Chưa có backend, đăng nhập, thanh toán, credit thật hoặc lệnh gọi AI thật. Thông tin dự án/chương trong HTML và JSON là dữ liệu mẫu; thay đổi trong trình duyệt chưa phải dữ liệu đồng bộ bền vững. API key trong màn hình tài khoản chỉ giữ trong tab, không có kết nối dịch vụ thật.

Nguyên tắc sản phẩm: tác giả nắm Canon và Author Decision. Bản AI tạo phải qua bước duyệt trước khi thành nội dung truyện; Context Builder phải xét đúng thời điểm, POV và những gì nhân vật đã biết. What-if cần tách khỏi Canon.
