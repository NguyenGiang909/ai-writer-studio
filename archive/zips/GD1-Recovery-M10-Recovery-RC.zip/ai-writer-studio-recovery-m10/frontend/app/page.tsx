import Link from "next/link";
export default function Home(){
 return <main style={{padding:40,maxWidth:900,margin:"auto"}}>
   <h1>AI Writer Studio</h1>
   <p>Writer-first Story OS — Recovery M1.</p>
   <p>M1 restores the executable Project → Volume → Arc → Chapter → Scene foundation.</p>
 </main>
}
