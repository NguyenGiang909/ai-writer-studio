import {getJSON} from "../../../lib/api";
export default async function Workspace({params}:{params:Promise<{projectId:string}>}){
 const {projectId}=await params;
 const tree=await getJSON(`/api/v1/projects/${projectId}/manuscript`);
 return <main style={{display:"grid",gridTemplateColumns:"280px 1fr 320px",minHeight:"100vh"}}>
  <aside style={{padding:20,borderRight:"1px solid #ddd"}}>
   <strong>Manuscript</strong>
   {tree.chapters.map((c:any)=><div key={c.id} style={{marginTop:16}}>
     <div>{c.order_index}. {c.title}</div>
     {c.scenes.map((s:any)=><div key={s.id} style={{paddingLeft:16,opacity:.7}}>{s.title ?? "Scene"}</div>)}
   </div>)}
  </aside>
  <section style={{padding:"48px 64px"}}><h1>Writer Workspace</h1><p>Select a Scene from the manuscript tree.</p></section>
  <aside style={{padding:20,borderLeft:"1px solid #ddd"}}><strong>AI Inspector</strong><p>Context / Notes / Review will be restored in later recovery milestones.</p></aside>
 </main>
}
