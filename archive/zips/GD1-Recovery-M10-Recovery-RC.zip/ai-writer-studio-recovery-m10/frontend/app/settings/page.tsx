
export default function Settings(){
 const sections=["Account","AI Providers","Model Settings","Usage & Cost","Writing Defaults","Data","Security"];
 return <main style={{padding:40,maxWidth:960,margin:"auto"}}><h1>Settings</h1>
 <p>Provider secrets are stored server-side and never returned in full.</p>
 <div style={{display:"grid",gridTemplateColumns:"220px 1fr",gap:32}}>
  <nav>{sections.map(x=><div key={x} style={{padding:"10px 0"}}>{x}</div>)}</nav>
  <section><h2>AI Providers</h2><p>Connect OpenAI, Anthropic, Gemini, OpenRouter or a custom provider.</p>
  <button>Connect provider</button><h2>Model routing</h2><p>Task → Project → Account → System fallback.</p></section>
 </div></main>
}
