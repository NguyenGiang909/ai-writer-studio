import React from "react";
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="vi"><body style={{margin:0,fontFamily:"system-ui"}}>{children}</body></html>
}
