# AI Writer Studio — GĐ1 Recovery M1

Recovery milestone M1 rebuilds the executable foundation of the Writer-first application.

## Included
- FastAPI backend
- async SQLAlchemy
- Alembic baseline migration
- Project → Volume → Arc → Chapter → Scene hierarchy
- project-scoped CRUD API
- Next.js workspace shell
- PostgreSQL/pgvector + Redis Docker Compose
- backend unit/contract tests

## Run
1. Copy `.env.example` to `.env`
2. `docker compose up --build`
3. API: http://localhost:8000
4. Web: http://localhost:3000
5. API docs: http://localhost:8000/docs

## Recovery rule
Every major recovery milestone must be packaged as a source ZIP.
