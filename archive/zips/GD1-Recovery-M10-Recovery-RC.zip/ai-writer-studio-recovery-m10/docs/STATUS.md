
# AI Writer Studio — GĐ1 Recovery M10 Status

## Recovery milestones implemented
- M1 Runtime + Manuscript
- M2 Story Database
- M3 Story Truth + Temporal contracts
- M4 Narrative Threads/Holes
- M5 AI Router + Context Budget/Manifest foundation
- M6 Writer Pipeline foundation
- M7 Story Room + Style preference foundation
- M8 After-write Suggestions + Continuity foundation
- M9 Hierarchical Long-Novel Memory + Impact/Retcon foundation
- M10 What-if Branch + Account/BYOK model routing + Settings shell

## Safety / authority invariants restored
- Project is the data boundary.
- AI generation is not Canon authority.
- Suggested changes default to not auto-applied.
- Knowledge has narrative acquisition order.
- Story time and narrative order are separate.
- Partial disclosure is represented explicitly.
- What-if merge creates AuthorDecision only; it does not mutate Canon/manuscript.
- Provider secret is server-side; public view exposes hint only.

## Important verification status
This is a RECOVERY BUILD reconstructed from retained architecture/specs.
It is NOT yet equivalent to the lost 262-test repository.

Packaging verification:
- all Python source files compile
- migrations 0001 → 0010 exist as a linear chain
- recovery contract tests are included

Still required before declaring GĐ1 FINAL:
1. install backend dependencies and run full pytest
2. run Alembic against real PostgreSQL/pgvector
3. Next.js npm install + typecheck + production build
4. implement full CRUD/API surfaces for M3–M10 (many current modules are service/model foundations)
5. provider encryption/key-management implementation (current model is contract only)
6. real provider E2E and retry/cost accounting
7. PostgreSQL + frontend + backend end-to-end tests
8. compare recovered OpenAPI against retained final handoff contract if available
