from pydantic import BaseModel, ConfigDict, Field

class ORMModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)

class ProjectCreate(BaseModel):
    name: str = Field(min_length=1, max_length=240)
    description: str | None = None
class ProjectOut(ORMModel):
    id: str; name: str; description: str | None = None

class VolumeCreate(BaseModel):
    title: str; order_index: int = 0
class VolumeOut(ORMModel):
    id: str; project_id: str; title: str; order_index: int

class ArcCreate(BaseModel):
    title: str; order_index: int = 0; volume_id: str | None = None
class ArcOut(ORMModel):
    id: str; project_id: str; title: str; order_index: int; volume_id: str | None = None

class ChapterCreate(BaseModel):
    title: str; order_index: int = 0; volume_id: str | None = None; arc_id: str | None = None
class ChapterOut(ORMModel):
    id: str; project_id: str; title: str; order_index: int; status: str
    volume_id: str | None = None; arc_id: str | None = None

class SceneCreate(BaseModel):
    title: str | None = None
    order_index: int = 0
    prose: str = ""
    pov_character_id: str | None = None
    scene_type: str | None = None
class ScenePatch(BaseModel):
    title: str | None = None
    prose: str | None = None
    pov_character_id: str | None = None
    scene_type: str | None = None
class SceneOut(ORMModel):
    id: str; project_id: str; chapter_id: str; title: str | None
    order_index: int; prose: str; pov_character_id: str | None; scene_type: str | None
