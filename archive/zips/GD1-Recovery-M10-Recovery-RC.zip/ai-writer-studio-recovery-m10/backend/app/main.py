from fastapi import FastAPI
from app.api.routes.health import router as health_router
from app.api.routes.manuscript import router as manuscript_router
from app.api.routes.story import router as story_router

app = FastAPI(title="AI Writer Studio", version="recovery-m1")
app.include_router(health_router)
app.include_router(manuscript_router, prefix="/api/v1")
app.include_router(story_router, prefix="/api/v1")
