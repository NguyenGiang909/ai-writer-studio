
from dataclasses import dataclass
@dataclass
class ModelRequest:
    task:str; prompt:str; model:str|None=None
class ModelRouter:
    def __init__(self,providers=None): self.providers=providers or {}
    async def complete(self,request:ModelRequest):
        provider=self.providers.get(request.model or "default")
        if not provider: raise RuntimeError("No AI provider configured")
        return await provider.complete(request.prompt)
