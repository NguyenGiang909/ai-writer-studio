
from fastapi import APIRouter,Depends,HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.models import *
from app.schemas.story import *
router=APIRouter()

async def project_ok(db,pid):
    if not await db.get(Project,pid): raise HTTPException(404,"project not found")
async def scoped(db,cls,obj_id,pid,label):
    obj=await db.get(cls,obj_id)
    if not obj or obj.project_id!=pid: raise HTTPException(400,f"{label} outside project")
    return obj
async def add(db,obj):
    db.add(obj); await db.commit(); await db.refresh(obj); return obj

@router.post("/projects/{pid}/characters")
async def create_character(pid:str,p:CharacterCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid); return await add(db,Character(project_id=pid,**p.model_dump()))

@router.get("/projects/{pid}/characters")
async def list_characters(pid:str,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid)
    return list((await db.scalars(select(Character).where(Character.project_id==pid).order_by(Character.name))).all())

@router.post("/projects/{pid}/world-entities")
async def create_world(pid:str,p:WorldEntityCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid); return await add(db,WorldEntity(project_id=pid,**p.model_dump()))

@router.post("/projects/{pid}/locations")
async def create_location(pid:str,p:LocationCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid)
    if p.parent_location_id: await scoped(db,Location,p.parent_location_id,pid,"parent location")
    return await add(db,Location(project_id=pid,**p.model_dump()))

@router.post("/projects/{pid}/factions")
async def create_faction(pid:str,p:NamedCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid); return await add(db,Faction(project_id=pid,**p.model_dump()))

@router.post("/projects/{pid}/items")
async def create_item(pid:str,p:ItemCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid); return await add(db,Item(project_id=pid,**p.model_dump()))

@router.post("/projects/{pid}/abilities")
async def create_ability(pid:str,p:AbilityCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid); return await add(db,Ability(project_id=pid,**p.model_dump()))

@router.post("/projects/{pid}/relationships")
async def create_relationship(pid:str,p:RelationshipCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid)
    await scoped(db,Character,p.source_character_id,pid,"source character")
    await scoped(db,Character,p.target_character_id,pid,"target character")
    if p.source_character_id==p.target_character_id: raise HTTPException(400,"relationship endpoints must differ")
    return await add(db,Relationship(project_id=pid,**p.model_dump()))

@router.post("/projects/{pid}/aliases")
async def create_alias(pid:str,p:AliasCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid); await scoped(db,Character,p.character_id,pid,"character")
    return await add(db,Alias(project_id=pid,**p.model_dump()))

@router.post("/projects/{pid}/character-arcs")
async def create_character_arc(pid:str,p:CharacterArcCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid); await scoped(db,Character,p.character_id,pid,"character")
    return await add(db,CharacterArc(project_id=pid,**p.model_dump()))

@router.post("/projects/{pid}/style-profiles")
async def create_style_profile(pid:str,p:StyleProfileCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid)
    allowed={"global","arc","character","scene_type"}
    if p.scope_type not in allowed: raise HTTPException(400,"invalid style scope")
    if p.scope_type=="global" and p.scope_id is not None: raise HTTPException(400,"global scope_id must be null")
    if p.scope_type=="arc" and p.scope_id: await scoped(db,Arc,p.scope_id,pid,"arc")
    if p.scope_type=="character" and p.scope_id: await scoped(db,Character,p.scope_id,pid,"character")
    return await add(db,StyleProfile(project_id=pid,**p.model_dump()))

@router.post("/projects/{pid}/style-samples")
async def create_style_sample(pid:str,p:StyleSampleCreate,db:AsyncSession=Depends(get_db)):
    await project_ok(db,pid); await scoped(db,StyleProfile,p.style_profile_id,pid,"style profile")
    return await add(db,StyleSample(project_id=pid,**p.model_dump()))
