from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.models import Project, Volume, Arc, Chapter, Scene
from app.schemas.manuscript import *

router = APIRouter()

async def project_or_404(db: AsyncSession, project_id: str):
    obj = await db.get(Project, project_id)
    if not obj: raise HTTPException(404, "project not found")
    return obj

@router.post("/projects", response_model=ProjectOut)
async def create_project(payload: ProjectCreate, db: AsyncSession=Depends(get_db)):
    obj=Project(**payload.model_dump()); db.add(obj); await db.commit(); await db.refresh(obj); return obj

@router.get("/projects", response_model=list[ProjectOut])
async def list_projects(db: AsyncSession=Depends(get_db)):
    return list((await db.scalars(select(Project).order_by(Project.created_at))).all())

@router.post("/projects/{project_id}/volumes", response_model=VolumeOut)
async def create_volume(project_id: str, payload: VolumeCreate, db: AsyncSession=Depends(get_db)):
    await project_or_404(db, project_id)
    obj=Volume(project_id=project_id, **payload.model_dump()); db.add(obj); await db.commit(); await db.refresh(obj); return obj

@router.post("/projects/{project_id}/arcs", response_model=ArcOut)
async def create_arc(project_id: str, payload: ArcCreate, db: AsyncSession=Depends(get_db)):
    await project_or_404(db, project_id)
    if payload.volume_id:
        v=await db.get(Volume,payload.volume_id)
        if not v or v.project_id != project_id: raise HTTPException(400,"volume outside project")
    obj=Arc(project_id=project_id, **payload.model_dump()); db.add(obj); await db.commit(); await db.refresh(obj); return obj

@router.post("/projects/{project_id}/chapters", response_model=ChapterOut)
async def create_chapter(project_id: str, payload: ChapterCreate, db: AsyncSession=Depends(get_db)):
    await project_or_404(db, project_id)
    if payload.volume_id:
        v=await db.get(Volume,payload.volume_id)
        if not v or v.project_id != project_id: raise HTTPException(400,"volume outside project")
    if payload.arc_id:
        a=await db.get(Arc,payload.arc_id)
        if not a or a.project_id != project_id: raise HTTPException(400,"arc outside project")
    obj=Chapter(project_id=project_id, **payload.model_dump()); db.add(obj); await db.commit(); await db.refresh(obj); return obj

@router.post("/projects/{project_id}/chapters/{chapter_id}/scenes", response_model=SceneOut)
async def create_scene(project_id: str, chapter_id: str, payload: SceneCreate, db: AsyncSession=Depends(get_db)):
    await project_or_404(db, project_id)
    ch=await db.get(Chapter,chapter_id)
    if not ch or ch.project_id != project_id: raise HTTPException(404,"chapter not found in project")
    obj=Scene(project_id=project_id, chapter_id=chapter_id, **payload.model_dump())
    db.add(obj); await db.commit(); await db.refresh(obj); return obj

@router.patch("/projects/{project_id}/scenes/{scene_id}", response_model=SceneOut)
async def patch_scene(project_id: str, scene_id: str, payload: ScenePatch, db: AsyncSession=Depends(get_db)):
    obj=await db.get(Scene,scene_id)
    if not obj or obj.project_id != project_id: raise HTTPException(404,"scene not found in project")
    for k,v in payload.model_dump(exclude_unset=True).items(): setattr(obj,k,v)
    await db.commit(); await db.refresh(obj); return obj

@router.get("/projects/{project_id}/manuscript")
async def manuscript_tree(project_id: str, db: AsyncSession=Depends(get_db)):
    await project_or_404(db, project_id)
    chapters=list((await db.scalars(select(Chapter).where(Chapter.project_id==project_id).order_by(Chapter.order_index))).all())
    scenes=list((await db.scalars(select(Scene).where(Scene.project_id==project_id).order_by(Scene.chapter_id,Scene.order_index))).all())
    by_ch={}
    for s in scenes: by_ch.setdefault(s.chapter_id,[]).append(SceneOut.model_validate(s).model_dump())
    return {"project_id":project_id,"chapters":[{**ChapterOut.model_validate(c).model_dump(),"scenes":by_ch.get(c.id,[])} for c in chapters]}
