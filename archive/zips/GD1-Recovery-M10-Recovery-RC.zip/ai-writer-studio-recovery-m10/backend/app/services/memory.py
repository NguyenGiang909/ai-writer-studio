
HIERARCHY=["scene","chapter","arc","volume","story"]
def invalidate_chain(scope_type):
    i=HIERARCHY.index(scope_type); return HIERARCHY[i:]
def bounded_backlog(items,limit=20):
    rank={x:i for i,x in enumerate(HIERARCHY)}
    return sorted([x for x in items if x.get("stale")],key=lambda x:rank.get(x.get("scope_type"),99))[:max(1,min(limit,100))]
def impact_preview(change_type,target_id,refs):
    hits=[r for r in refs if target_id in r.get("references",[])]
    return {"change_type":change_type,"target_id":target_id,"affected":hits,"auto_apply":False}
