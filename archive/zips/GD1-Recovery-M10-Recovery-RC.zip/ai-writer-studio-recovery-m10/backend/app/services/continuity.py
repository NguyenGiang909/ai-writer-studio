
from dataclasses import dataclass
@dataclass
class Issue:
    code:str; category:str; severity:str; message:str; evidence:dict
def dedupe(issues:list[Issue]):
    out={}; rank={"info":0,"warning":1,"error":2}
    for i in issues:
        key=(i.code,tuple(sorted((i.evidence or {}).items())))
        if key not in out or rank.get(i.severity,0)>rank.get(out[key].severity,0): out[key]=i
    return list(out.values())
def knowledge_leak(known_narrative_order:int|None,scene_narrative_order:int|None):
    if known_narrative_order is not None and scene_narrative_order is not None and known_narrative_order>scene_narrative_order:
        return Issue("KNOWLEDGE_LEAK","knowledge","error","Information is acquired later in narrative history.",{"acquired":known_narrative_order,"scene":scene_narrative_order})
