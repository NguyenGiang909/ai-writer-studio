
def public_credential_view(provider,key_hint,status="connected"):
    return {"provider":provider,"key_hint":key_hint,"status":status,"secret":None}
def resolve_model(task,task_override=None,project_override=None,account_default=None,system_fallback=None):
    return task_override or project_override or account_default or system_fallback
