
from app.db.base import Base
import app.models
def test_m2_tables_present():
    expected={"projects","volumes","arcs","chapters","scenes","characters","world_entities","locations","factions","items","abilities","relationships","aliases","character_arcs","style_profiles","style_samples"}
    assert set(Base.metadata.tables)==expected
def test_all_story_tables_are_project_scoped():
    for name in set(Base.metadata.tables)-{"projects"}:
        assert "project_id" in Base.metadata.tables[name].c
